"""Core backend utilities."""
